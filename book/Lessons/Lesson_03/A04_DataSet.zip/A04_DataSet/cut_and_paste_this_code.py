###########################################################
# SET YOUR VARIABLES - choose the data file name and the type of sigma value
###########################################################

s = "sigma"                   # choose type of sigma value
#s = "s_plus"
#s = "s_minus"

data_set = "200"          # choose data set


###########################################################
# HIT GO UNTIL YOU ARE DONE
# The code that follows does not need to be altered. Just run it  
# using the variables and packages that you set up above.
# Who needs ChatGPT when you have Cut & Paste?
###########################################################

###########################################################
# SET UP THE ENVIRONMENT - load packages and define functions
###########################################################

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as stats

def fill_sigma(df):           # a function to fill in sigma for empty spaces in s+ and s-
    for z in df.index:
        if np.isnan(df.loc[z,"s_plus"]):
            df.loc[z,"s_plus"] = df.loc[z,"sigma"]
        if np.isnan(df["s_minus"][z]):
            df.loc[z,"s_minus"] = df.loc[z,"sigma"]
    return(df)


###########################################################
# READ RATE DATA - read in the chosen data set
###########################################################

print(data_set)

df = pd.read_csv(data_set + ".csv",          # read in data file as dataframe
                 delimiter = ",", 
                 skipinitialspace=True, 
                 index_col="Substituent", 
                 comment = "#") 

df["logk"] = np.log10(df["kobs"])   # calculate a new column for log(k)
#print(df)

###########################################################
# READ HAMMETT DATA - read in the chosen database of sigma values
###########################################################

datafile = "LFER_HanschLeoTaft.csv"         # Choose database for sigma values
#datafile = "LFER_Williams.csv"

df2 = pd.read_csv(datafile,                 # Read in database as dataframe
                 delimiter = ",", 
                 skipinitialspace=True, 
                 index_col="Substituent", 
                 comment = "#") 

df2=fill_sigma(df2)         # Clean and process data
#print(df2)

rowlist = df.index          # Get names in the index column of data
df["sigma"]=df2[s][rowlist] # copy in the corresponding sigma values from df2

print(df)


###########################################################
### PLOT the line fit and the data 
###########################################################

x = df["sigma"]        # get x and y values from dataframe
y = df["logk"]

plt.scatter(x,y, color="black")              # Plot data

linfit = stats.linregress(x,y)               # Line fit
fity = linfit.slope * x + linfit.intercept   # Calculate your values from line fit

plt.plot(x, fity, color='black')             # Plot line using x and calculated y values

plt.xlabel(r"$\sigma$")                      # Set titles and labels                     
plt.ylabel(r"$\log{k_{obs}}$")
plt.title("test")
plt.xlim((-1,1.3))                           # Set range of x-axis

plt.savefig(f"plot_{data_set}.pdf")   # use this to save the figure in PDF format
plt.show()                  # output the combined plot plots


###########################################################
### PRINT the line fit parameters 
###########################################################

print()
print(f"slope = {linfit.slope:0.3f} +/- {linfit.stderr:0.3f}")
print(f"intercept = {linfit.intercept:0.3f} +/- +/- {linfit. intercept_stderr:0.3f}")
print(f"RSQ = {(linfit.rvalue**2):0.3f}")